package P10_pb;

public class S5_3 {
	public static void main(String[] args) {	
		P10_pc.Car car1=new P10_pc.Car();
		car1.show();
	}
}