package P19;

public class P19 {
	public static void main(String[] args) {	
		int[] test=new int[5];
		System.out.println("將值指定給test[10]");
		
		test[10]=80;
		System.out.println("將80指定給test[10]");
		System.out.println("順利的執行完畢");
	}
}