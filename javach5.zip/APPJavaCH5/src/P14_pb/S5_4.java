package P14_pb;
import P14_pc.Car;
public class S5_4 {
	public static void main(String[] args) {	
		Car car1=new Car();
		car1.show();
	}
}
