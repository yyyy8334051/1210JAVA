package P8;
public class S5_2 {
	public static void main(String[] args) {	
		Car car1=new Car();
		car1.show();
	}
}